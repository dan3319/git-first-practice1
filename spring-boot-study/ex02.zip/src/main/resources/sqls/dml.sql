INSERT INTO TBl_BOARD (title, content, writer)
	VALUES ('테스트 제목', '테스트 내용', 'user00')
;